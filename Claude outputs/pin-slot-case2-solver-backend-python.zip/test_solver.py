import time
from solver import solve


def run(name, data, opts=None):
    t0 = time.time()
    out = solve(data, opts)
    ms = (time.time() - t0) * 1000
    print(f"\n=== {name} ({ms:.0f} ms) ===")
    print(out)
    return out


# --- Case A: default example values from the page (same as GROUPS defaults) ---
VC_B_L = 8 + 0.005 + 0.01
VC_B_U = 8.04 - 0.01 - 0.01
G_B = (VC_B_U - VC_B_L) / 2

VC_C_L = 8 + 0.005 + 0.02
VC_W_U = 8.05 - 0.01 - 0.01
G_CW = (VC_W_U - VC_C_L) / 2

VC_L_U = 12 - 0.1 - 0.2
G_CL = (VC_L_U - VC_C_L) / 2

holes = [
    {"x": 20, "y": 40},
    {"x": 100, "y": 40},
    {"x": 20, "y": -40},
    {"x": 100, "y": -40},
]

print("G_B =", G_B, " G_CW =", G_CW, " G_CL =", G_CL)

r1 = run("Default example values", {"x_Pin2": 120, "G_B": G_B, "G_CW": G_CW, "G_CL": G_CL, "holes": holes})
assert r1["ok"]
shifts = [r["shift_max"] for r in r1["results"]]
print("shift_max per hole:", shifts)
assert shifts[1] >= shifts[0] - 1e-9
assert shifts[3] >= shifts[2] - 1e-9
for i, s in enumerate(shifts):
    assert s >= G_B - 1e-6, f"hole{i+1} shift ({s}) should be >= G_B ({G_B})"
# symmetry: hole1/hole3 (same |y|) and hole2/hole4 should match
assert abs(shifts[0] - shifts[2]) < 1e-6
assert abs(shifts[1] - shifts[3]) < 1e-6

# --- Case B: zero play everywhere -> shift must be exactly 0 ---
r2 = run("Zero play", {"x_Pin2": 120, "G_B": 0, "G_CW": 0, "G_CL": 0, "holes": holes})
assert r2["ok"] and all(r["shift_max"] == 0 for r in r2["results"])

# --- Case C: negative G_B should be rejected ---
r3 = run("Negative G_B (should error)", {"x_Pin2": 120, "G_B": -0.01, "G_CW": G_CW, "G_CL": G_CL, "holes": holes})
assert r3["ok"] is False

# --- Case D: larger, more generous play, to exercise a wider sweep & check symmetry ---
r4 = run(
    "Generous play (symmetry check)",
    {"x_Pin2": 120, "G_B": 0.05, "G_CW": 0.05, "G_CL": 0.1,
     "holes": [{"x": 100, "y": 40}, {"x": 100, "y": -40}]},
    {"N_THETA": 600, "N_LIN": 250},
)
assert r4["ok"]
print("symmetric holes shift_max:", [r["shift_max"] for r in r4["results"]])
assert abs(r4["results"][0]["shift_max"] - r4["results"][1]["shift_max"]) < 1e-3

print("\nAll assertions passed (no AssertionError raised above means success).")
