"""
PUBLIC HTTP WRAPPER ONLY. See solver.py for the actual brute-force
translation + rotation registration-shift search - this file just
exposes it as a POST /calculate endpoint for the public page to call.
"""

import os
from flask import Flask, request, jsonify
from flask_cors import CORS

from solver import solve

app = Flask(__name__)
CORS(app)


@app.route("/", methods=["GET"])
def health():
    return jsonify({"ok": True, "service": "pin-slot-case2-solver"})


@app.route("/calculate", methods=["POST"])
def calculate():
    try:
        data = request.get_json(force=True, silent=True) or {}
        result = solve(data)
        return jsonify(result)
    except Exception as err:  # pragma: no cover
        return jsonify({"ok": False, "errors": [f"Internal error: {err}"]}), 500


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
