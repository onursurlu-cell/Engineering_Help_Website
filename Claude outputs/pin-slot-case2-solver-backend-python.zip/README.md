# pin-slot-case2-solver

Private Railway backend for the **Pin–Slot Located Non-Alignable Assembly Calculator**
(`pin-slot-non-alignable-assembly-calculator/` on onurhelps.com).

Python/Flask, matching the stack of the other two backends in this Railway
project (Bolt Pretension, Rigid-Body Solver).

It does exactly one thing: given the datum-feature play (`G_B`, `G_CW`, `G_CL`),
the Pin 1 → Pin 2 lever arm (`x_Pin2`), and the four shoulder-bolt holes' basic
(x, y) locations, it runs a dense brute-force sweep of every (dx, dy, θ)
registration-shift combination the datum play structurally allows, and returns,
independently for each hole, the single worst registration shift found. Nothing
engineering-specific (part tolerances, gauge formulas) lives here — that all
stays in the public page's own JavaScript, in full view. This service is only
the expensive geometric search.

## Files

- `solver.py` — the actual brute-force search. Pure function `solve(data)`,
  only depends on NumPy (used to vectorize the (dx, dy) sweep for speed —
  see "Performance" below — every point in the grid is still genuinely
  evaluated, nothing is skipped except points the geometry itself rules out).
- `app.py` — thin Flask + flask-cors wrapper exposing `solve()` as `POST /calculate`.
- `test_solver.py` — a few sanity checks (symmetry, zero-play, rejection of
  invalid input) you can run with `python3 test_solver.py` any time you touch
  `solver.py`.
- `requirements.txt` — Python dependencies.
- `Procfile` — tells Railway to run it with `gunicorn` (production WSGI server).

## Request / response contract

`POST /calculate`, JSON body:

```json
{
  "x_Pin2": 120,
  "G_B": 0.0025,
  "G_CW": 0.0025,
  "G_CL": 1.8375,
  "holes": [
    {"x": 20, "y": 40},
    {"x": 100, "y": 40},
    {"x": 20, "y": -40},
    {"x": 100, "y": -40}
  ]
}
```

Response (success):

```json
{
  "ok": true,
  "results": [
    {"index": 1, "x": 20, "y": 40, "shift_max": 0.00348, "config_at_max": {"dx": ..., "dy": ..., "theta": ...}},
    ...
  ],
  "meta": { "N_THETA": 1500, "N_LIN": 400, "theta_window_deg": 0.0029,
            "combinations_feasible": ..., "elapsed_ms": 3000, "timed_out": false }
}
```

On bad input (e.g. a negative `G_B`): `{"ok": false, "errors": ["..."]}`.

The page computes the actual worst-case gap itself (`C_gap - shift_max`, where
`C_gap` is the same formula the hand-assembled calculator already uses as its
final answer) — this service only returns the geometric shift.

## Deploying

Same pattern as your other two backends: its own GitHub repo, deployed as its
own service inside the same Railway project (`lively-analysis`).

1. Push these files to a new, empty GitHub repo (e.g. `Pin_Slot_Case2_Solver`).
2. In Railway, inside the `lively-analysis` project: **+ Add → GitHub Repo**,
   pick that repo. Railway auto-detects Python from `requirements.txt` and the
   `Procfile` and runs `gunicorn app:app`.
3. No environment variables are required (it reads `PORT` from Railway
   automatically, same as the Procfile's `$PORT`).
4. Once deployed, open the new service's **Settings → Networking** tab and
   generate/confirm its public domain — something like
   `https://<something>-production.up.railway.app`.
5. **Update the frontend**: in
   `pin-slot-non-alignable-assembly-calculator/index.html`, find the line

   ```js
   const API_URL = "https://pinslotcase2solver-production.up.railway.app/calculate";
   ```

   and replace the URL with the real one Railway assigned (append `/calculate`).
   That placeholder was only a guess at Railway's naming convention — it will
   not work until you swap in the real URL.

## Performance

With the example values already on the page, the full 4-hole sweep (1500
rotation steps × a 400×400 translation grid) runs in about **3 seconds**
locally. That's comfortably inside the ~20-second budget the Calculate button
is designed around, with margin to spare even on a slower/shared container.

`gunicorn`'s worker timeout is set to 25 seconds in the `Procfile` so a slow
request is never killed mid-calculation; `solver.py` also has its own
18-second internal time limit (`TIME_LIMIT_S`) that returns the best result
found so far (flagged `meta.timed_out: true`) rather than ever hanging.

## Tuning

`solver.py` has constants near the top:

```python
N_THETA = 1500  # steps across the full rotation window
N_LIN = 400     # steps across each of dx and dy
TIME_LIMIT_S = 18.0  # abort and return best-so-far past this
```

Raise `N_THETA`/`N_LIN` for finer resolution at the cost of more time; lower
them if a request ever runs long in practice on Railway's hardware.
