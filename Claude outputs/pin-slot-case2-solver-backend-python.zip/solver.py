"""
Pin-Slot Non-Alignable Assembly Calculator - registration-shift solver.
Pure computational core (no Flask/HTTP here) so it can be imported and
unit-tested on its own (see test_solver.py).

Physical model
--------------
Part U sits on Part L through two datum engagements:
  - Pin 1 / Hole 1U  (datum B): a round pin in a round hole, so Part U's
    datum origin can sit anywhere in a disk of radius G_B around the
    nominal (centered) position.
  - Pin 2 / Slot     (datum C): Pin 2 is a round pin, but the slot only
    constrains it directionally - width play G_CW (Y, perpendicular to
    the slot) and length play G_CL (X, along the slot).

Once the two parts are seated (lowered onto the pins once, no retry -
the "non-alignable" case), Part U's whole body sits at SOME translation
(dx, dy) of its datum origin plus SOME rotation theta about that origin,
constrained by both engagements above. Which exact (dx, dy, theta) occurs
on any given real assembly is not knowable in advance, so the design must
be checked against every combination the tolerances structurally allow.

For each shoulder-bolt hole, at its nominal (basic) location (x, y)
relative to Pin 1, the rigid-body motion displaces the mating threaded
hole in Part U by:
    shift_x = dx + x*cos(theta) - y*sin(theta) - x
    shift_y = dy + x*sin(theta) + y*cos(theta) - y
This solver searches the ENTIRE feasible (dx, dy, theta) region - a dense
grid, not a closed-form shortcut - and returns, independently for each
hole, the single worst (largest-magnitude) registration shift found
anywhere in that region. The public page turns that into a worst-case gap
using the part/gauge tolerances it already has on screen.

Every combination is genuinely evaluated; nothing is skipped except
combinations the geometry itself rules out (outside the Pin 1 disk, or
outside the slot's width/length play). The (dx, dy) sweep is vectorized
with NumPy for speed - that is a performance detail, not a shortcut: it
still evaluates every grid point, just many at once instead of one at a
time in a Python-level loop (which would be far too slow in pure Python).
"""

import time
import numpy as np

# ---- Grid resolution (tune here; higher = slower, finer) ----
N_THETA = 1500  # steps across the full rotation window
N_LIN = 400     # steps across each of dx and dy (so N_LIN^2 per theta)
TIME_LIMIT_S = 18.0  # abort and return best-so-far if this is exceeded


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


def solve(data, opts=None):
    opts = opts or {}
    n_theta0 = opts.get("N_THETA", N_THETA)
    n_lin0 = opts.get("N_LIN", N_LIN)
    time_limit_s = opts.get("TIME_LIMIT_S", TIME_LIMIT_S)

    x_Pin2 = data.get("x_Pin2")
    G_B = data.get("G_B")
    G_CW = data.get("G_CW")
    G_CL = data.get("G_CL")
    holes = data.get("holes")

    errors = []
    if not (isinstance(x_Pin2, (int, float)) and np.isfinite(x_Pin2) and x_Pin2 > 0):
        errors.append("x_Pin2 must be a positive number.")
    if not (isinstance(G_B, (int, float)) and np.isfinite(G_B)):
        errors.append("G_B must be a number.")
    if not (isinstance(G_CW, (int, float)) and np.isfinite(G_CW)):
        errors.append("G_CW must be a number.")
    if not (isinstance(G_CL, (int, float)) and np.isfinite(G_CL)):
        errors.append("G_CL must be a number.")
    if not (isinstance(holes, list) and len(holes) >= 1):
        errors.append("holes must be a non-empty array of {x,y}.")
    if errors:
        return {"ok": False, "errors": errors}

    if G_B < 0 or G_CW < 0 or G_CL < 0:
        return {"ok": False, "errors": [
            "G_B, G_CW and G_CL must all be zero or positive - fix the datum-feature fits first."
        ]}
    for h in holes:
        if not (isinstance(h.get("x"), (int, float)) and np.isfinite(h.get("x"))
                and isinstance(h.get("y"), (int, float)) and np.isfinite(h.get("y"))):
            return {"ok": False, "errors": ["Every hole entry needs numeric x and y."]}

    n_holes = len(holes)
    hx = np.array([h["x"] for h in holes], dtype=np.float64)
    hy = np.array([h["y"] for h in holes], dtype=np.float64)

    # Degenerate case: no play at all anywhere - only (0,0,0) is feasible.
    if G_B == 0 and G_CW == 0 and G_CL == 0:
        results = [
            {"index": i + 1, "x": float(hx[i]), "y": float(hy[i]), "shift_max": 0.0,
             "config_at_max": {"dx": 0.0, "dy": 0.0, "theta": 0.0}}
            for i in range(n_holes)
        ]
        return {"ok": True, "results": results, "meta": {
            "N_THETA": 1, "N_LIN": 1, "theta_window_deg": 0.0,
            "note": "No play available (G_B = G_CW = G_CL = 0); only the nominal position is feasible.",
        }}

    # Rotation window: how far Part U could rotate about Pin 1 and still keep
    # Pin 2 inside the slot's width/length play, taking into account that Pin 1
    # itself can also shift by up to G_B to help satisfy that. This is a
    # generous bound used only to SIZE the sweep - the grid below still checks
    # the real constraints at every single point regardless.
    rCL = _clamp((G_CL + G_B) / x_Pin2, 0, 1) if x_Pin2 > 0 else 1.0
    rCW = _clamp((G_CW + G_B) / x_Pin2, 0, 1) if x_Pin2 > 0 else 1.0
    theta_max = min(np.arccos(1 - rCL), np.arcsin(rCW))
    if not np.isfinite(theta_max) or theta_max <= 0:
        theta_max = 1e-6
    theta_max = min(theta_max * 1.2, np.pi / 4)  # 20% safety margin, sane cap

    n_theta = max(3, int(n_theta0))
    n_lin = max(3, int(n_lin0))

    lin = np.linspace(-G_B, G_B, n_lin)
    DX, DY = np.meshgrid(lin, lin, indexing="xy")  # each shape (n_lin, n_lin)
    disk_mask = (DX * DX + DY * DY) <= (G_B * G_B)
    # Flattened, Pin-1-disk-only view: points outside the disk can never be
    # feasible at any theta, so they are dropped once, up front, rather than
    # re-filtered on every theta step. This is still the full search - it
    # just skips the part of the bounding square that's geometrically
    # impossible regardless of rotation.
    disk_idx = np.nonzero(disk_mask.reshape(-1))[0]
    DXd = DX.reshape(-1)[disk_idx]
    DYd = DY.reshape(-1)[disk_idx]

    thetas = np.linspace(-theta_max, theta_max, n_theta)

    max_shift2 = np.full(n_holes, -1.0)
    best = [{"dx": 0.0, "dy": 0.0, "theta": 0.0} for _ in range(n_holes)]

    t0 = time.time()
    timed_out = False
    combinations_feasible = 0

    for it, theta in enumerate(thetas):
        if (it & 63) == 0 and (time.time() - t0) > time_limit_s:
            timed_out = True
            break

        c, s = np.cos(theta), np.sin(theta)
        slotX = DXd + x_Pin2 * (c - 1)
        slotY = DYd + x_Pin2 * s
        feas_mask = (slotX >= -G_CL) & (slotX <= G_CL) & (slotY >= -G_CW) & (slotY <= G_CW)
        n_feas = int(feas_mask.sum())
        if n_feas == 0:
            continue
        combinations_feasible += n_feas
        DXf = DXd[feas_mask]
        DYf = DYd[feas_mask]

        # All holes at once (batched over a leading "hole" axis) instead of a
        # per-hole Python loop, and restricted to the (small) set of points
        # that passed both the Pin-1-disk and slot-play tests for this theta
        # - shift_x/shift_y are DXf/DYf plus a per-hole SCALAR offset (the
        # hole's own basic location only enters through that offset), so
        # every hole's shift field is built from the same feasible-point
        # list with broadcasting - one vectorized pass per theta step
        # instead of n_holes separate ones, and over far fewer points than
        # the full (dx, dy) grid.
        offset_x = hx * (c - 1) - hy * s   # shape (n_holes,)
        offset_y = hx * s + hy * (c - 1)   # shape (n_holes,)
        SX = DXf[None, :] + offset_x[:, None]
        SY = DYf[None, :] + offset_y[:, None]
        S2 = SX * SX + SY * SY
        idxs = np.argmax(S2, axis=1)
        vals = S2[np.arange(n_holes), idxs]
        improved = vals > max_shift2
        if improved.any():
            for h in np.nonzero(improved)[0]:
                max_shift2[h] = vals[h]
                j = idxs[h]
                best[h] = {"dx": float(DXf[j]), "dy": float(DYf[j]), "theta": float(theta)}

    results = []
    for h in range(n_holes):
        shift_max = float(np.sqrt(max_shift2[h])) if max_shift2[h] >= 0 else 0.0
        results.append({
            "index": h + 1, "x": float(hx[h]), "y": float(hy[h]),
            "shift_max": shift_max, "config_at_max": best[h],
        })

    return {
        "ok": True,
        "results": results,
        "meta": {
            "N_THETA": n_theta, "N_LIN": n_lin,
            "theta_window_deg": float(theta_max * 180 / np.pi),
            "combinations_feasible": combinations_feasible,
            "elapsed_ms": int((time.time() - t0) * 1000),
            "timed_out": timed_out,
        },
    }
