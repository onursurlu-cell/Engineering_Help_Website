const { solve } = require("./solver");

function approxEqual(a, b, tol) { return Math.abs(a - b) <= tol; }

function run(name, input, opts) {
  const t0 = Date.now();
  const out = solve(input, opts);
  const ms = Date.now() - t0;
  console.log(`\n=== ${name} (${ms} ms) ===`);
  console.log(JSON.stringify(out, null, 2));
  return out;
}

// --- Case A: default example values from the page (same as GROUPS defaults) ---
const VC_B_L = 8 + 0.005 + 0.01;          // 8.015
const VC_B_U = 8.04 - 0.01 - 0.01;        // 8.02
const G_B = (VC_B_U - VC_B_L) / 2;        // 0.0025

const VC_C_L = 8 + 0.005 + 0.02;          // 8.025
const VC_W_U = 8.05 - 0.01 - 0.01;        // 8.03
const G_CW = (VC_W_U - VC_C_L) / 2;       // 0.0025

const VC_L_U = 12 - 0.1 - 0.2;            // 11.7
const G_CL = (VC_L_U - VC_C_L) / 2;       // 1.8375

const holes = [
  { x: 20, y: 40 },
  { x: 100, y: 40 },
  { x: 20, y: -40 },
  { x: 100, y: -40 },
];

console.log("G_B =", G_B, " G_CW =", G_CW, " G_CL =", G_CL);

const r1 = run("Default example values", { x_Pin2: 120, G_B, G_CW, G_CL, holes });

// Sanity checks
console.assert(r1.ok, "expected ok result");
const shifts = r1.results.map(r => r.shift_max);
console.log("shift_max per hole:", shifts);
// Farther holes (x=100) should have >= shift than nearer holes (x=20) at the same y,
// since rotation about Pin 1 displaces them more.
console.assert(shifts[1] >= shifts[0] - 1e-9, "hole2 (x=100) should shift >= hole1 (x=20)");
console.assert(shifts[3] >= shifts[2] - 1e-9, "hole4 (x=100) should shift >= hole3 (x=20)");
// Every shift should be at least G_B (pure translation alone already achieves that).
shifts.forEach((s, i) => console.assert(s >= G_B - 1e-6, `hole${i+1} shift (${s}) should be >= G_B (${G_B})`));

// --- Case B: zero play everywhere -> shift must be exactly 0 ---
const r2 = run("Zero play", { x_Pin2: 120, G_B: 0, G_CW: 0, G_CL: 0, holes });
console.assert(r2.ok && r2.results.every(r => r.shift_max === 0), "zero play should give zero shift");

// --- Case C: negative G_B should be rejected ---
const r3 = run("Negative G_B (should error)", { x_Pin2: 120, G_B: -0.01, G_CW, G_CL, holes });
console.assert(r3.ok === false, "negative G_B must be rejected");

// --- Case D: larger, more generous play, to exercise a wider sweep & check symmetry ---
const r4 = run("Generous play (symmetry check)", {
  x_Pin2: 120, G_B: 0.05, G_CW: 0.05, G_CL: 0.1,
  holes: [ { x: 100, y: 40 }, { x: 100, y: -40 } ],
}, { N_THETA: 600, N_LIN: 250 });
console.assert(r4.ok, "expected ok");
console.log("symmetric holes shift_max:", r4.results.map(r => r.shift_max));
console.assert(approxEqual(r4.results[0].shift_max, r4.results[1].shift_max, 1e-3), "symmetric holes (same |y|) should have ~equal shift");

console.log("\nAll assertions passed (no assertion errors printed above means success).");
