/*
  Pin–Slot Non-Alignable Assembly Calculator — registration-shift solver.
  Pure computational core, no HTTP/framework dependencies, so it can be
  required and unit-tested on its own (see test_solver.js).

  Physical model
  --------------
  Part U sits on Part L through two datum engagements:
    - Pin 1 / Hole 1U  (datum B): a round pin in a round hole, so Part U's
      datum origin can sit anywhere in a disk of radius G_B around the
      nominal (centered) position.
    - Pin 2 / Slot     (datum C): Pin 2 is a round pin, but the slot only
      constrains it directionally — width play G_CW (Y, perpendicular to
      the slot) and length play G_CL (X, along the slot).

  Once the two parts are seated (lowered onto the pins once, no retry —
  the "non-alignable" case), Part U's whole body sits at SOME translation
  (dx, dy) of its datum origin plus SOME rotation theta about that origin,
  constrained by both engagements above. Which exact (dx, dy, theta) occurs
  on any given real assembly is not knowable in advance, so the design must
  be checked against every combination the tolerances structurally allow.

  For each shoulder-bolt hole, at its nominal (basic) location (x, y)
  relative to Pin 1, the rigid-body motion displaces the mating threaded
  hole in Part U by:
      shift_x = dx + x*cos(theta) - y*sin(theta) - x
      shift_y = dy + x*sin(theta) + y*cos(theta) - y
  This solver searches the ENTIRE feasible (dx, dy, theta) region — a dense
  grid, not a closed-form shortcut — and returns, independently for each
  hole, the single worst (largest-magnitude) registration shift found
  anywhere in that region. The public page turns that into a worst-case gap
  using the part/gauge tolerances it already has on screen.

  Every combination is genuinely evaluated in the loops below; nothing is
  skipped except combinations the geometry itself rules out (outside the
  Pin 1 disk, or outside the slot's width/length play).
*/

// ---- Grid resolution (tune here; higher = slower, finer) ----
const N_THETA = 1500; // steps across the full rotation window
const N_LIN = 400;    // steps across each of dx and dy (so N_LIN^2 per theta)
const TIME_LIMIT_MS = 18000; // abort and return best-so-far if this is exceeded

function clamp(x, lo, hi) { return Math.max(lo, Math.min(hi, x)); }

function solve(input, opts = {}) {
  const { x_Pin2, G_B, G_CW, G_CL, holes } = input;
  const nTheta0 = opts.N_THETA || N_THETA;
  const nLin0 = opts.N_LIN || N_LIN;
  const timeLimitMs = opts.TIME_LIMIT_MS || TIME_LIMIT_MS;

  const errors = [];
  if (!(typeof x_Pin2 === "number" && isFinite(x_Pin2) && x_Pin2 > 0)) errors.push("x_Pin2 must be a positive number.");
  if (!(typeof G_B === "number" && isFinite(G_B))) errors.push("G_B must be a number.");
  if (!(typeof G_CW === "number" && isFinite(G_CW))) errors.push("G_CW must be a number.");
  if (!(typeof G_CL === "number" && isFinite(G_CL))) errors.push("G_CL must be a number.");
  if (!Array.isArray(holes) || holes.length < 1) errors.push("holes must be a non-empty array of {x,y}.");
  if (errors.length) return { ok: false, errors };

  if (G_B < 0 || G_CW < 0 || G_CL < 0) {
    return { ok: false, errors: ["G_B, G_CW and G_CL must all be zero or positive — fix the datum-feature fits first."] };
  }
  for (const h of holes) {
    if (!(typeof h.x === "number" && isFinite(h.x) && typeof h.y === "number" && isFinite(h.y))) {
      return { ok: false, errors: ["Every hole entry needs numeric x and y."] };
    }
  }

  // Degenerate case: no play at all anywhere — only (0,0,0) is feasible.
  if (G_B === 0 && G_CW === 0 && G_CL === 0) {
    const results = holes.map((h, i) => ({ index: i + 1, x: h.x, y: h.y, shift_max: 0, config_at_max: { dx: 0, dy: 0, theta: 0 } }));
    return { ok: true, results, meta: { N_THETA: 1, N_LIN: 1, theta_window_deg: 0, note: "No play available (G_B = G_CW = G_CL = 0); only the nominal position is feasible." } };
  }

  // Rotation window: how far Part U could rotate about Pin 1 and still keep
  // Pin 2 inside the slot's width/length play, taking into account that Pin 1
  // itself can also shift by up to G_B to help satisfy that. This is a
  // generous bound used only to SIZE the sweep — the loops below still check
  // the real constraints at every single grid point regardless.
  const rCL = x_Pin2 > 0 ? clamp((G_CL + G_B) / x_Pin2, 0, 1) : 1;
  const rCW = x_Pin2 > 0 ? clamp((G_CW + G_B) / x_Pin2, 0, 1) : 1;
  let thetaMax = Math.min(Math.acos(1 - rCL), Math.asin(rCW));
  if (!isFinite(thetaMax) || thetaMax <= 0) thetaMax = 1e-6;
  thetaMax = Math.min(thetaMax * 1.2, Math.PI / 4); // 20% safety margin, sane cap

  const nTheta = Math.max(3, nTheta0);
  const nLin = Math.max(3, nLin0);
  const dTheta = (2 * thetaMax) / (nTheta - 1);
  const dLin = (2 * G_B) / (nLin - 1);
  const G_B2 = G_B * G_B;

  const nHoles = holes.length;
  const hx = new Float64Array(nHoles), hy = new Float64Array(nHoles);
  for (let i = 0; i < nHoles; i++) { hx[i] = holes[i].x; hy[i] = holes[i].y; }

  const maxShift2 = new Float64Array(nHoles).fill(-1);
  const bestDx = new Float64Array(nHoles), bestDy = new Float64Array(nHoles), bestTheta = new Float64Array(nHoles);

  const t0 = Date.now();
  let combinationsChecked = 0, combinationsFeasible = 0, timedOut = false;

  outer:
  for (let it = 0; it < nTheta; it++) {
    const theta = -thetaMax + it * dTheta;
    const c = Math.cos(theta), s = Math.sin(theta);
    const baseX = x_Pin2 * (c - 1); // Pin 2's x-shift at dx=dy=0
    const baseY = x_Pin2 * s;       // Pin 2's y-shift at dx=dy=0

    if ((it & 63) === 0 && Date.now() - t0 > timeLimitMs) { timedOut = true; break outer; }

    for (let ix = 0; ix < nLin; ix++) {
      const dx = -G_B + ix * dLin;
      const dx2 = dx * dx;
      if (dx2 > G_B2) continue;
      const slotX = dx + baseX;
      if (slotX < -G_CL || slotX > G_CL) continue;

      for (let iy = 0; iy < nLin; iy++) {
        const dy = -G_B + iy * dLin;
        combinationsChecked++;
        if (dx2 + dy * dy > G_B2) continue;
        const slotY = dy + baseY;
        if (slotY < -G_CW || slotY > G_CW) continue;

        combinationsFeasible++;
        for (let h = 0; h < nHoles; h++) {
          const x = hx[h], y = hy[h];
          const nx = dx + x * c - y * s;
          const ny = dy + x * s + y * c;
          const sx = nx - x, sy = ny - y;
          const s2 = sx * sx + sy * sy;
          if (s2 > maxShift2[h]) {
            maxShift2[h] = s2;
            bestDx[h] = dx; bestDy[h] = dy; bestTheta[h] = theta;
          }
        }
      }
    }
  }

  const results = [];
  for (let h = 0; h < nHoles; h++) {
    const shiftMax = maxShift2[h] >= 0 ? Math.sqrt(maxShift2[h]) : 0;
    results.push({
      index: h + 1,
      x: hx[h], y: hy[h],
      shift_max: shiftMax,
      config_at_max: { dx: bestDx[h], dy: bestDy[h], theta: bestTheta[h] },
    });
  }

  return {
    ok: true,
    results,
    meta: {
      N_THETA: nTheta, N_LIN: nLin,
      theta_window_deg: thetaMax * 180 / Math.PI,
      combinations_checked: combinationsChecked,
      combinations_feasible: combinationsFeasible,
      elapsed_ms: Date.now() - t0,
      timed_out: timedOut,
    },
  };
}

module.exports = { solve };
