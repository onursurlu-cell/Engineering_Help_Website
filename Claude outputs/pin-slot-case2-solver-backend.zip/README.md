# pin-slot-case2-solver

Private Railway backend for the **Pin–Slot Located Non-Alignable Assembly Calculator**
(`pin-slot-non-alignable-assembly-calculator/` on onurhelps.com).

It does exactly one thing: given the datum-feature play (`G_B`, `G_CW`, `G_CL`),
the Pin 1 → Pin 2 lever arm (`x_Pin2`), and the four shoulder-bolt holes' basic
(x, y) locations, it runs a dense brute-force sweep of every (dx, dy, θ)
registration-shift combination the datum play structurally allows, and returns,
independently for each hole, the single worst registration shift found. Nothing
engineering-specific (part tolerances, gauge formulas) lives here — that all
stays in the public page's own JavaScript, in full view. This service is only
the expensive geometric search.

## Files

- `solver.js` — the actual brute-force search. Zero dependencies, pure
  function `solve(input)`. This is the only file with real logic in it.
- `server.js` — thin Express/CORS wrapper exposing `solve()` as `POST /calculate`.
- `test_solver.js` — a few sanity checks (symmetry, zero-play, rejection of
  invalid input) you can run with `node test_solver.js` any time you touch
  `solver.js`.
- `package.json` — dependencies (`express`, `cors`).

## Request / response contract

`POST /calculate`, JSON body:

```json
{
  "x_Pin2": 120,
  "G_B": 0.0025,
  "G_CW": 0.0025,
  "G_CL": 1.8375,
  "holes": [
    {"x": 20, "y": 40},
    {"x": 100, "y": 40},
    {"x": 20, "y": -40},
    {"x": 100, "y": -40}
  ]
}
```

Response (success):

```json
{
  "ok": true,
  "results": [
    {"index": 1, "x": 20, "y": 40, "shift_max": 0.00348, "config_at_max": {"dx": ..., "dy": ..., "theta": ...}},
    ...
  ],
  "meta": { "N_THETA": 1500, "N_LIN": 400, "theta_window_deg": 0.0029,
            "combinations_checked": ..., "combinations_feasible": ...,
            "elapsed_ms": 1370, "timed_out": false }
}
```

On bad input (e.g. a negative `G_B`): `{"ok": false, "errors": ["..."]}`.

The page computes the actual worst-case gap itself (`C_gap - shift_max`, where
`C_gap` is the same formula the hand-assembled calculator already uses as its
final answer) — this service only returns the geometric shift.

## Deploying

This was written to match the existing `bolt-pretension` and `rigid-body-solver`
backends: a small Express service, one Railway service per calculator, same
Railway project (a second project was blocked on the current plan, but
additional services in the same project work fine).

1. Put these files in their own repo (or a subfolder of wherever the other two
   backends live) and push to GitHub.
2. In Railway: **New Service → Deploy from GitHub repo**, pick this repo/folder.
3. No environment variables are required (it reads `PORT` from Railway
   automatically).
4. Once deployed, Railway will give you a URL like
   `https://<something>-production.up.railway.app`.
5. **Update the frontend**: in
   `pin-slot-non-alignable-assembly-calculator/index.html`, find the line

   ```js
   const API_URL = "https://pinslotcase2solver-production.up.railway.app/calculate";
   ```

   and replace the URL with the real one Railway assigned (append `/calculate`).
   That placeholder was only a guess at Railway's naming convention — it will
   not work until you swap in the real URL.

## Tuning

`solver.js` has two constants near the top:

```js
const N_THETA = 1500; // steps across the full rotation window
const N_LIN = 400;    // steps across each of dx and dy
const TIME_LIMIT_MS = 18000; // abort and return best-so-far past this
```

With the example values on the page, the full 4-hole sweep ran in about
1.4 seconds locally. If you want finer resolution (smaller steps) at the cost
of more time, raise `N_THETA`/`N_LIN`; if a request ever runs long, lower them.
`TIME_LIMIT_MS` is a safety net so a request can never hang indefinitely — past
that point it returns the best result found so far with `meta.timed_out: true`.
