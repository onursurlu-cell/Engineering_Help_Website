/*
  PUBLIC HTTP WRAPPER ONLY. See solver.js for the actual brute-force
  translation + rotation registration-shift search — this file just
  exposes it as a POST /calculate endpoint for the public page to call.
*/

const express = require("express");
const cors = require("cors");
const { solve } = require("./solver");

const app = express();
app.use(cors());
app.use(express.json({ limit: "256kb" }));

app.get("/", (req, res) => res.json({ ok: true, service: "pin-slot-case2-solver" }));

app.post("/calculate", (req, res) => {
  try {
    const result = solve(req.body || {});
    res.json(result);
  } catch (err) {
    res.status(500).json({ ok: false, errors: ["Internal error: " + err.message] });
  }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`pin-slot-case2-solver listening on ${PORT}`));
